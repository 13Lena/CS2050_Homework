/*
 * CS2050 - Computer Science II - Summer 2021
 * Instructor: Thyago Mota
 * Description: Activity 06 - LinkedListDriver
 * Name: Lena Hamilton
 * Date: June 19, 2021
 */


import java.util.Random;

public class LinkedListDriver {
    public static void main(String[] args) {
        // TODO #2: create a linked list and add 100 random integers ranging from 0-99 (must use a loop)
        LinkedList linkedList = new LinkedList();
    for(int i = 0; i < 100; i++) {
        Random random = new Random();
        int rand = random.nextInt(100);
        linkedList.append(rand);
    } 

        // TODO #3: show the linked list elements using toString
        String linkedListElements = linkedList.toString();
    System.out.println("\nElements on the Linked List:\n"+linkedListElements);

        // TODO #4: show the number of elements of the linked list using size
        System.out.println("\nNumber of Elements in the Linked List: "+linkedList.size());
    }
}

