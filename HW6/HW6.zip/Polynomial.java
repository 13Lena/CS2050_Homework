/*
 * CS 2050 - Computer Science II - Summer 2021
 * Instructor: Thyago Mota
 * Description: Activity 07 - Polynomial
 * Name: Lena Hamilton
 * Date June 27, 2021
 */
package Homework.HW6;

public class Polynomial {

    private Term firstTerm;

    public Polynomial() {
        firstTerm = null;
    }

    // TODO #1: return the maximum exponent value of the polynomial
    public int degree() {
        return 0;
    }

    // TODOd: return the number of terms of the polynomial
    public int size() {
        int count = 0;
        Term current = firstTerm;
        while (current != null) {
            count++;
            current = current.getNext();
        }
        return count;
    }

    // TODOd: add the given term to the polynomial (see activity instructions for
    // more detailed information)
    void addTerm(final Term term) {
        Term newTerm = (Term) term.clone();
        if (size() == 0)
            firstTerm = newTerm;
        else {
            Term previous = null;
            Term current = firstTerm;
            while (current != null) {
                if (newTerm.getExponent() > current.getExponent()) {
                    newTerm.setNext(current);
                    if (current == firstTerm)
                        firstTerm = newTerm;
                    else
                        previous.setNext(newTerm);
                    return;
                } else if (newTerm.getExponent() == current.getExponent()) {
                    current.add(newTerm);
                    return;
                } else {
                    previous = current;
                    current = current.getNext();
                }
            }
            previous.setNext(newTerm);
        }
    }

    // TODOd: add the terms of the given polynomial to the callee polynomial; hint:
    // traverse the given
    // polynomial and call addTerm to add each of its terms to the callee polynomial
    void add(final Polynomial other) {
        Term current = other.firstTerm;
        while (current != null) {
            addTerm(current);
            current = current.getNext();
        }
    }

    // TODO #2: traverse the callee polynomial and call toString from each of its
    // terms to generate
    // a string representation of the polynomial; use the following examples to
    // figure it out the
    // format to use:
    // 8x^3 -2x^2 + 7x + 3.2
    @Override
    public String toString() {
        return "";
    }

    // TODOd: return the term with the given exponent; null if the term does not
    // exist
    Term getTerm(int exponent) {
        Term current = firstTerm;
        while (current != null) {
            if (current.getExponent() == exponent)
                return current;
            else if (current.getExponent() < exponent)
                break;
            current = current.getNext();
        }
        return null;
    }
}